In order for this mod to work, while ingame set all pickaxe parts to Company Standard and replace the skin with Gadgeteer.

If anyone questions, bugs or concerns don't be afraid to ask me @SirVerex on the DRGModding Discord.