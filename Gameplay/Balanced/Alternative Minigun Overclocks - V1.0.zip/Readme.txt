Extreme Feed Mechanism (Minigun OC) - v1.0

An aftermarket mod which pushes the rotary mechanism of the minigun to the extreme. Even the best engine lubricant on Hoxxes has a hard time keeping the excess heat generation in check. This replaces the Compact Feed Mechanism overclock.
+25 fire-rate
+300% heat generation

Freezing Hell (Minigun OC) - v1.0

These high-tech bullets are designed to devastate frozen enemies and convert into cryo-minelets that will super-cool anything that comes close after impacting the terrain. However they don't last forever and the rounds themselves take more space in the drum and deal less direct damage. Additionally, these super-cooled rounds will reduce the heat output of the minigun chamber. This replaces the Bullet Hell overlock.
Cryo-minelets deal 4 cold damage and have 0 arming delay
x2 damage on frozen enemies
+0.8 cooling rate
-4 damage
-400 ammo

Lead Storm Reworked (Minigun OC) - v1.0

Increased raw damage in exchange for reduction of ammo, stun chance, and weakspot damage. Results in better damage versus armoured enemies.
+10 damage
-300 ammo
x0 stun chance
x0 stun duration
x0 movement speed
x0 weakspot damage

Prototype Cybernetics (Minigun OC) - v1.01

A prototype leaked from the Deep Rock Robotics Department. This integrated cybernetic solution aims to mitigate the physical strain experienced when handling heavy weaponry; However, this incomplete iteration lacks the AI aim assist which some consider necessary to alleviate the increased bullet spread. This replaces the Exhaust Vectoring overclock.
+75% movespeed while using
+300 ammo,
+700% spread

Cryo Ammo (Minigun OC) - v1.0

Converts the cooling capacity of the minigun chamber to store cryo bullets. This replaces the Thinned Drum Walls overclock.
Adds ice damage to bullets
-1 cooling rate

Radioactive Rounds (Minigun OC)

Bullets infused with radioactive material. This replaces the Burning Hell overclock.
Adds chance to inflict 'Radiation Sickness' to enemies
-2 rate of fire
