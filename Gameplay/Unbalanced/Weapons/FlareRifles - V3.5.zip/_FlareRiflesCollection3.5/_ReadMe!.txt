Note: Only use one of these pak files at a time. This mod will not show up in the blueprint manager mod. This mod will conflict with 
anything that messes with the flare gun, or that one weapon modification on the assault rifle that increases stagger chance when 
hitting a weakspot. 

(If you take the stun modification for the Flare Rifle, you do not need to aim for the weakspot, and the chance is 100%)

Due to... something, I wasn't able to add the heat and stun modifications in the same mod in the way i wanted to, but they work
fine on their own.





If you're updating the Flare Rifle mod, make sure to remove the older version.