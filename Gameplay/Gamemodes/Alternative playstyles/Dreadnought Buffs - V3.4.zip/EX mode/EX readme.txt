This is the mode you should consider playing on if you're running the mod on vanilla haz 5. 
For each dreadnought, it uses the most powerful aspects of their two versions.

The EX hiveguard buff mod will conflict with the normal hiveguard buff mod. Same for the OG and twins. 
One mod per dreadnought, but you can mix them up as you wish. 