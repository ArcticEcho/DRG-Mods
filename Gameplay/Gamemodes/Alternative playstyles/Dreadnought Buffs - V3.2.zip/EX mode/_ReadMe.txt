This is the mode you should consider playing on if you're running the mod on vanilla haz 5. 
For each dreadnought, it uses the most powerful aspects of their two versions.
