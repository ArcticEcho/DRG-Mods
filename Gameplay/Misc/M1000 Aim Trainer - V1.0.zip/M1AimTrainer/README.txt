Mod Description:
This mod is designed as an aim trainer for Scout's M1000 to warm up your shots or practicing in general by making it so you only do actual damage through weakpoint hits with the M1k.
This mod is meant to be used with GoldBl4d3's Spawn Menu mod (which also requires the BP Mod Manager) and replaces Haz 4 and 5 files along with modifications to missions.
Read the README for more details.

----
How to use:
- Move this mod's pak file into your Paks folder
- Download GoldBl4d3's Spawn Menu mod which also requires downloading BP Mod Manager, then move them into your Paks folder. Mods can be found here: https://github.com/ArcticEcho/DRG-Mods

- Using the Spawn Menu in-game (default key is "N" to open BP Mod Manager"), 
  create and customize your own spawn profiles for the targets you will be practicing against.
- If you want to disable Bosco, you can do so by unchecking the bottom left checkbox "Bring Bosco" in Bosco's terminal.
- If you need more ammo, you can spawn a Resupply pod using the Spawn Menu.
- Since this mod also modifies the game that is disadvantageous in normal play (see changes below); once you're done practicing, 
  just temporarily move this mod's pak file out of your Paks folder to disable it and move it back in when you want to train again (restart game to apply changes). 

Changes:
- M1000's base damage decreased down to 1
- M1000's T4 mod Weakpoint Bonus increased to 5400% to one hit regular grunts in their mouth's weakpoint
- M1000's base ammo increased to 500

- Hazard 4 and 5 no longer spawn hostile enemies and some of the stationary enemies. 
- Hazard 4 and 5 Bonus is set to 0% 

Since Haz 4 and 5 no longer spawn enemies, the following modifications were made to prevent unintended use of this mod:
- All Primary and Secondary Objectives no longer give experience and credits upon completion.
- Most of the resources no longer give experience when deposited
- Deposited gold no longer gives credits

---
Changelog
v1.0 - U34 H5
First release:
- M1000's base damage decreased down to 1
- M1000's T4 mod Weakpoint Bonus increased to 5400% to one hit regular grunts in their mouth's weakpoint
- M1000's base ammo increased to 500
- Hazard 4 and 5 no longer spawn hostile enemies and some of the stationary enemies. 
- Hazard 4 and 5 Bonus is set to 0% 
- All Primary and Secondary Objectives no longer give experience and credits upon completion.
- Most of the resources no longer give experience when deposited
- Deposited gold no longer gives credits