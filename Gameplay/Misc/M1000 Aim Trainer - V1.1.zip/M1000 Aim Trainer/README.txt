Mod Description:
This mod is designed as an aim trainer for Scout's M1000 by making it so you only do actual damage through weakpoint hits with the M1k.
This mod is meant to be used with GoldBl4d3's Spawn Menu mod (which also requires the BP Mod Manager).
Read the README for more details on how to use the mod as intended. 

----
How to use this mod:
* Downloading Mods
- Move this mod's pak file into your Paks folder
- Download GoldBl4d3's Spawn Menu mod which also requires downloading BP Mod Manager, then move both of them into your Paks folder. 
  Mods can be found here: https://github.com/ArcticEcho/DRG-Mods

* Using Spawn Menu (can be accessed by opening BP Mod Manager, default key "N")
- To prevent natural enemy spawns; go to "CONFIG" tab --> "--SETTINGS--" section --> Enable the checkbox for "Prevent Creature Spawns"
- Create and customize your own spawn profiles for the targets you will be practicing against under "PROFILES" tab
- If you want to disable Bosco, you can do so by unchecking the bottom left checkbox "Bring Bosco" in Bosco's terminal.
- If you need more ammo, you can spawn a Resupply pod under "TOOLS" tab --> "--EQUIPMENT--" section --> "Supply Pod"

* Using the Mod
- Start up a solo match on any mission with Scout and aim away!
- Once you're done practicing and want the normal M1k back, just temporarily move this mod's pak file out of your Paks folder to disable it 
  and move it back in when you want to train again (restart game to apply changes). 

---
Mod Changes:
- M1000's base damage decreased down to 1
- M1000's T4 mod Weakpoint Bonus increased to 5400% to one hit regular grunts in their mouth's weakpoint
- M1000's base ammo increased to 500
